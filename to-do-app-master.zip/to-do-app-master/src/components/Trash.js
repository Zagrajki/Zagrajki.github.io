import React, { Component } from 'react';

class Trash extends Component {
    state = {  }
    render() {
        return ( <div>Trash</div> );
    }
}

export default Trash;
